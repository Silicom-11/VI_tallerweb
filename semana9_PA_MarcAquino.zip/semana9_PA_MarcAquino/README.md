# 🌟 Samsung Galaxy Z Fold7 - Página Web Oficial Completa

Una réplica fiel y funcional de la página oficial de Samsung con todas las secciones, carruseles interactivos y footer completo.

## 📁 Estructura del Proyecto

```
semana9/
├── index.html              # Página principal HTML
├── styles.css              # Estilos CSS completos
├── script.js               # JavaScript para carruseles
├── sources/                # Carpeta de imágenes (36 imágenes)
│   ├── README.md          # Lista detallada de imágenes
│   └── [imágenes...]
└── README.md              # Este archivo
```

## ✨ Características Implementadas

### 🔝 Header
- Logo SAMSUNG
- Menú de navegación: Tienda Online, Móviles, TV y Audio, Línea Blanca, Monitores, Accesorios
- Links superiores: Soporte, Para Empresas
- Iconos: Búsqueda, Carrito, Usuario
- Sticky/Fixed al hacer scroll

### 🎯 Hero Section
- Título grande "Galaxy Z Fold7"
- Subtítulo "Galaxy AI" con emoji ✨
- Botones "Más información" y "Comprar"
- Imagen principal del producto
- Botón de reproducción
- Diseño responsivo

### 🎨 Secciones de Contenido
1. **Promoción Galaxy S25 FE** - Banner grande con imagen
2. **Productos Móviles** - Grid de 4 productos (Galaxy Z Fold7, Flip, Watch, Buds)
3. **Promoción 2025 AI TVs** - Banner tecnología
4. **Productos Entretenimiento** - Grid de 4 productos (TVs, Monitores, Audio)
5. **Promoción Bespoke AI** - Banner electrodomésticos
6. **Productos Bespoke** - Grid de 4 productos (Refrigerador, Lavandería, etc.)

### 🎪 Carrusel "Recomendado para ti"
- 10 productos con imágenes
- Precios en **negrita**
- "Ahorra" en **color azul** (#0066cc)
- Precio original tachado
- Navegación con flechas ← → debajo del carrusel
- Scroll suave y animado
- Responsive (scroll horizontal en móviles)

### 📚 Carrusel "Explora las Historias"
- 5 tarjetas con imágenes grandes
- Títulos descriptivos
- Navegación con flechas ← → debajo
- Efectos hover elegantes
- Diseño en cards redondeadas

### 🦶 Footer Completo
**Secciones del Footer:**
- Disclaimer legal (texto pequeño superior)
- 5 columnas de links:
  - Tienda (9 links)
  - Productos (13 links)
  - Soporte (15 links)
  - Cuenta (6 links)
  - Sustentabilidad (6 links)
- Sección "Sobre Samsung" (8 links horizontales)
- Copyright y info de empresa
- 4 logos de partners (La Cucharita, A Buen Puerto, QR Code, Samsung Shop)
- Links legales: Perú/Español, Privacidad, Legal, Mapa del Sitio
- Redes sociales: Facebook, Twitter, Instagram, YouTube, LinkedIn
- "Mantente informado" label

**Elementos Flotantes:**
- Botón "Preferencias de cookies" (abajo izquierda)
- Avatar chatbot circular (abajo derecha)
- Botón "Comentarios" (lateral derecho)

## 🎨 Tecnologías Utilizadas

- **HTML5** - Estructura semántica
- **CSS3** - Diseño moderno con:
  - Flexbox
  - CSS Grid
  - Animaciones y transiciones
  - Media queries responsive
- **JavaScript (Vanilla)** - Carruseles interactivos

## 📱 Diseño Responsive

- **Desktop** (>1024px): Diseño completo, todas las funciones
- **Tablet** (768px - 1024px): Grid adaptado, carruseles ajustados
- **Mobile** (<768px): Una columna, scroll horizontal en carruseles

## 🖼️ Imágenes Requeridas (36 total)

Coloca todas las imágenes en la carpeta `sources/`. Ver `sources/README.md` para la lista completa.

### Resumen por Categoría:
- **Hero Section**: 1 imagen
- **Promociones**: 3 imágenes grandes
- **Productos (Grids)**: 12 imágenes
- **Carrusel Recomendados**: 10 imágenes
- **Carrusel Historias**: 5 imágenes
- **Footer**: 5 imágenes (logos, QR, chatbot)

## 🚀 Cómo Usar

1. **Coloca las 36 imágenes** en la carpeta `sources/` con los nombres exactos
2. **Abre** `index.html` en tu navegador web
3. **Disfruta** de la página completamente funcional

## 🎯 Funcionalidades JavaScript

- Navegación de carrusel con botones
- Desplazamiento suave
- Botones deshabilitados en extremos
- Responsive adaptativo
- Múltiples carruseles independientes

## 🎨 Paleta de Colores

- **Negro**: `#000` - Textos principales
- **Gris oscuro**: `#555` - Textos secundarios
- **Gris claro**: `#f4f4f4` - Fondos
- **Azul Samsung**: `#1428a0` - Links y acentos
- **Azul descuento**: `#0066cc` - Texto "Ahorra"
- **Blanco**: `#fff` - Fondos principales

## 📝 Características Especiales

✅ Sticky header con navegación completa
✅ Hero section con gradiente suave
✅ Carruseles con navegación funcional
✅ Precios formateados con descuentos destacados
✅ Footer multi-columna con todos los links
✅ Iconos SVG para redes sociales
✅ Efectos hover en todos los elementos interactivos
✅ Botón de chat flotante
✅ Botón de cookies personalizado
✅ Completamente responsive
✅ Animaciones suaves CSS
✅ Tipografía tipo Samsung

## 🏆 Resultado Final

Una página web profesional que replica fielmente el diseño de Samsung.com con:
- **Diseño pixel-perfect**
- **Funcionalidad completa**
- **Código limpio y organizado**
- **Performance optimizado**
- **UX/UI de primera calidad**

---

**Desarrollado con dedicación y atención al detalle** 💙
