// Función genérica para carruseles
function initCarousel(trackSelector, prevBtnSelector, nextBtnSelector, itemSelector, itemsPerView = 4) {
    const track = document.querySelector(trackSelector);
    const prevBtn = document.querySelector(prevBtnSelector);
    const nextBtn = document.querySelector(nextBtnSelector);
    const items = document.querySelectorAll(itemSelector);
    
    if (!track || !prevBtn || !nextBtn || items.length === 0) return;
    
    const itemWidth = items[0].offsetWidth;
    const gap = 20; // Gap entre items
    const scrollAmount = itemWidth + gap;
    
    let currentPosition = 0;
    const maxScroll = -(scrollAmount * (items.length - itemsPerView)); // Mostrar N items a la vez
    
    // Función para actualizar la posición
    function updateCarousel() {
        track.style.transform = `translateX(${currentPosition}px)`;
        
        // Deshabilitar botones en los extremos
        prevBtn.disabled = currentPosition >= 0;
        nextBtn.disabled = currentPosition <= maxScroll;
        
        // Estilos visuales para botones deshabilitados
        if (prevBtn.disabled) {
            prevBtn.style.opacity = '0.5';
            prevBtn.style.cursor = 'not-allowed';
        } else {
            prevBtn.style.opacity = '1';
            prevBtn.style.cursor = 'pointer';
        }
        
        if (nextBtn.disabled) {
            nextBtn.style.opacity = '0.5';
            nextBtn.style.cursor = 'not-allowed';
        } else {
            nextBtn.style.opacity = '1';
            nextBtn.style.cursor = 'pointer';
        }
    }
    
    // Evento click para botón anterior
    prevBtn.addEventListener('click', function() {
        if (currentPosition < 0) {
            currentPosition += scrollAmount;
            if (currentPosition > 0) currentPosition = 0;
            updateCarousel();
        }
    });
    
    // Evento click para botón siguiente
    nextBtn.addEventListener('click', function() {
        if (currentPosition > maxScroll) {
            currentPosition -= scrollAmount;
            if (currentPosition < maxScroll) currentPosition = maxScroll;
            updateCarousel();
        }
    });
    
    // Inicializar
    updateCarousel();
    
    // Actualizar al cambiar tamaño de ventana
    window.addEventListener('resize', function() {
        currentPosition = 0;
        updateCarousel();
    });
}

// Inicializar carruseles cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    // Carrusel de productos recomendados
    initCarousel('.carousel-track', '.carousel-btn-prev', '.carousel-btn-next', '.carousel-item', 4);
    
    // Carrusel de historias
    initCarousel('.carousel-track-stories', '.carousel-btn-prev-stories', '.carousel-btn-next-stories', '.story-card', 4);
});
