# Instrucciones para Imágenes

Coloca las siguientes imágenes en esta carpeta `sources/`:

## Imágenes requeridas:

### Hero Section:
1. **galaxy-fold.png** - Imagen del Galaxy Z Fold7 para el hero section (parte superior de la página)

### Promociones:
2. **promocion.png** - Imagen de la promoción Galaxy S25 FE | Buds3 FE con Galaxy AI
3. **promocion2.png** - Imagen de la promoción 2025 AI TVs - Samsung Vision AI
4. **bespoke.png** - Imagen de la promoción Bespoke AI

### Productos Móviles:
5. **galaxyz.png** - Imagen del producto Galaxy Z Fold7
6. **galaxyz flip.png** - Imagen del producto Galaxy Z Flip 7 FE
7. **galaxy watch.png** - Imagen del producto Galaxy Watch8 Classic
8. **galaxy buds 3.png** - Imagen del producto Galaxy Buds3 FE

### Productos de Entretenimiento:
9. **neoqled.png** - Imagen del producto Neo QLED 8K
10. **theframe.png** - Imagen del producto The Frame
11. **barrasonido.png** - Imagen del producto Barra de sonido Q-Series
12. **odyssey.png** - Imagen del producto Odyssey OLED G8

### Productos Bespoke:
13. **refrigerador.png** - Imagen del Refrigerador Bespoke AI
14. **bespoke lavanderia.png** - Imagen del Bespoke AI Lavandería
15. **bespoke AI.png** - Imagen del Bespoke AI WindFree
16. **bespoke jet.png** - Imagen del Bespoke Jet

### Carrusel - Recomendado para ti:
17. **galaxyzfold.png** - Galaxy Z Fold7
18. **galaxys25ultra.png** - Galaxy S25 Ultra
19. **galaxyzflip7.png** - Galaxy Z Flip7
20. **galaxya565g.png** - Galaxy A56 5G
21. **galaxybudscore.png** - Galaxy Buds Core
22. **65crystal.png** - 65'' Crystal UHD U8000F Smart TV (2025)
23. **galaxytab.png** - Galaxy Tab S10 FE
24. **soundbar.png** - Soundbar Samsung Serie B 2.0 Ch. B400F
25. **galaxywatch7.png** - Galaxy Watch7 (Bluetooth, 40mm)
26. **aspiradora.png** - Aspiradora de arrastre con 370W de Poder

### Carrusel - Explora las Historias:
27. **smartthings.png** - SmartThings
28. **televisor.png** - ¿Por qué elegir Samsung Smart TV?
29. **samsung.png** - Samsung Health
30. **switch.png** - Switch to Galaxy
31. **tv.png** - TV para juegos

### Footer - Logos y Extras:
32. **lacucharita.png** - Logo La Cucharita (partner)
33. **abuenpuerto.png** - Logo A Buen Puerto (partner)
34. **qrcode.png** - Código QR
35. **samsungshop.png** - Logo Samsung Shop descargar
36. **chatbot.png** - Avatar del asistente virtual (chatbot)

## Nota:
Los nombres de archivo deben ser exactamente como están escritos arriba (incluyendo espacios y mayúsculas/minúsculas).
