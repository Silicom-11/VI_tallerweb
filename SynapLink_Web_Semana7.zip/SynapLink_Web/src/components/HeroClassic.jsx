export function HeroClassic(){
  return(
    <section className="hero-classic wrapper" id="inicio">
      <div className="hero-copy hero-classic-right">
        <span className="hero-eyebrow">Automatiza soporte</span>
        <h1 className="hero-title">Atiende clientes<br/>en segundos, sin espera</h1>
        <p className="hero-sub">Integra un cerebro conversacional que entiende contexto, actúa sobre tus sistemas y resuelve tickets antes de que tu equipo humano intervenga.</p>
        <div className="hero-actions">
          <button className="btn btn-primary">Probar ahora</button>
          <button className="btn btn-ghost">Ver demo</button>
        </div>
      </div>
      <div className="device-stack">
        <div className="device">
          <div className="screen">
            <strong>Chat en vivo</strong>
            <small style={{marginTop:8,opacity:.7}}>Simulación UI</small>
          </div>
        </div>
        <div className="checklist">
          <div className="check-item"><span className="icon">✓</span> Respuestas naturales</div>
          <div className="check-item"><span className="icon">✓</span> Acceso a tus datos</div>
          <div className="check-item"><span className="icon">✓</span> Aprende y mejora</div>
          <div className="check-item"><span className="icon">✓</span> Multi‑idioma</div>
        </div>
      </div>
    </section>
  )
}
export default HeroClassic;
