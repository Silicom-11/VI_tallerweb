export default function PorQueSection() {
  return (
    <div className="section" id="por-que" aria-labelledby="por-que-title">
      <h2 id="por-que-title" style={{ textAlign: 'center', fontSize: 32, marginBottom: 6 }}>
        Software para cybercafés y centros de gaming — SynapLink
      </h2>
      <p style={{ textAlign: 'center', color: 'var(--muted)', fontSize: 20, fontStyle: 'italic', marginTop: 0 }}>
        ¿Buscas la mejor solución para gestionar tu cibercafé o centro de juegos?
      </p>
    </div>
  );
}
