export function HighlightCTA(){
  return (
    <section className="wrapper" id="cta">
      <div className="highlight-cta">
        <h3>Implementa tu operador IA<br/>en días, no meses</h3>
        <p>Te acompañamos en la conexión de fuentes, definición de dominios y guardrails. Empieza con un piloto seguro y escala gradualmente.</p>
        <div className="actions">
          <button className="btn btn-primary">Iniciar prueba</button>
          <button className="btn btn-ghost">Hablar con ventas</button>
        </div>
      </div>
    </section>
  )
}
export default HighlightCTA;
