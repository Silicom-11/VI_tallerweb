export function WhySection(){
  const items = [
    {icon:'⚡', title:'Tiempo de respuesta', text:'Promedio < 2s gracias a contexto cacheado y rutas inteligentes.'},
    {icon:'🧠', title:'Comprensión real', text:'Procesa intención, entidades y estado conversacional de largo plazo.'},
    {icon:'🔗', title:'Integraciones', text:'Conecta CRM, ticketing y bases de conocimiento sin fricción.'},
    {icon:'🛡️', title:'Seguridad', text:'Controles de acceso y anonimización de PII integrados.'},
    {icon:'📈', title:'Aprendizaje continuo', text:'Refuerza respuestas según feedback y métricas.'},
    {icon:'🌍', title:'Multi‑idioma', text:'Modelo adapta tono y matices culturales automáticamente.'}
  ];
  return (
    <section className="why wrapper" id="por-que">
      <div className="center">
        <h2 style={{fontSize:44,margin:0,letterSpacing:'-1px'}}>¿Por qué <span style={{color:'var(--accent)'}}>SynapLink</span>?</h2>
        <p className="muted max-600" style={{margin:'14px auto 0'}}>Reducimos costos operativos sin sacrificar experiencia. Tu equipo se enfoca en casos complejos mientras la IA resuelve el resto.</p>
      </div>
      <div className="why-grid">
        {items.map(i => (
          <div key={i.title} className="feature-card">
            <div className="feature-icon">{i.icon}</div>
            <h3 className="feature-title">{i.title}</h3>
            <p className="feature-text">{i.text}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
export default WhySection;
