import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './styles.css';
import App from './App.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Dashboard from './pages/Dashboard.jsx';

const rootEl = document.getElementById('root');
if (!rootEl) {
  console.error('[SynapLink] #root no encontrado');
} else {
  // debug helper: visit ?debugRender=1 to force-render a visible test box
  const params = new URLSearchParams(window.location.search);
  const debugRender = params.get('debugRender') === '1';

  if (debugRender) {
    createRoot(rootEl).render(
      <div style={{height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(180deg,#06040e,#03030a)'}}>
        <div style={{padding: 24, borderRadius: 12, background: '#2b0f4a', color: '#fff', boxShadow: '0 10px 30px rgba(0,0,0,0.6)'}}>
          <h2 style={{margin: 0}}>DEBUG: React montado correctamente</h2>
          <p style={{margin: '8px 0 0 0'}}>Si ves este mensaje, React y Vite funcionan; el problema está dentro de <code>App</code> o sus componentes.</p>
        </div>
      </div>
    );
  } else {
    createRoot(rootEl).render(
      <StrictMode>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<App />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/dashboard" element={<Dashboard />} />
          </Routes>
        </BrowserRouter>
      </StrictMode>
    );
  }
}
