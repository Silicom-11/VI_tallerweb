import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';

export default function Register() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);

    // build payload expected by backend
    const names = (name || '').trim().split(/\s+/);
    const firstName = names[0] || '';
    const lastName = names.length > 1 ? names.slice(1).join(' ') : '';
    const username = (email && email.split('@')[0]) || (firstName + (lastName ? ('_' + lastName) : '')) || 'user' + Date.now();

    const payload = {
      username,
      firstName,
      lastName,
      gender: 'other',
      birthDate: '1990-01-01',
      email,
      password,
    };

    try {
      const res = await api.auth.register(payload);
      if (res && res.user) {
        navigate('/dashboard');
      } else {
        setError('Respuesta inesperada del servidor');
      }
    } catch (err) {
      console.error(err);
      const serverMsg = err && err.body && err.body.message;
      setError(serverMsg || err.message || 'Error al registrar');
    }
  }

  return (
    <div className="page-container">
      <h2>Crear cuenta</h2>
      <form onSubmit={handleSubmit} className="auth-form">
        <label>
          Nombre completo
          <input value={name} onChange={e => setName(e.target.value)} type="text" required />
        </label>
        <label>
          Email
          <input value={email} onChange={e => setEmail(e.target.value)} type="email" required />
        </label>
        <label>
          Contraseña
          <input value={password} onChange={e => setPassword(e.target.value)} type="password" required />
        </label>
        <button type="submit">Registrar</button>
        {error && <p className="error">{error}</p>}
      </form>
    </div>
  );
}
