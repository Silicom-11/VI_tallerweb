import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';

export default function Register() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);

    // build payload expected by backend
    const names = (name || '').trim().split(/\s+/);
    const firstName = names[0] || '';
    const lastName = names.length > 1 ? names.slice(1).join(' ') : '';
    const username = (email && email.split('@')[0]) || (firstName + (lastName ? ('_' + lastName) : '')) || 'user' + Date.now();

    const payload = {
      username,
      firstName,
      lastName,
      gender: 'other',
      birthDate: '1990-01-01',
      email,
      password,
    };

    try {
      const res = await api.auth.register(payload);
      if (res && res.user) {
        navigate('/dashboard');
      } else {
        setError('Respuesta inesperada del servidor');
      }
    } catch (err) {
      console.error(err);
      const serverMsg = err && err.body && err.body.message;
      setError(serverMsg || err.message || 'Error al registrar');
    }
  }

  return (
    <div className="page-container">
      <div className="auth-card">
        <h2>Crear cuenta</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <input className="input" placeholder="Nombre completo" value={name} onChange={e => setName(e.target.value)} type="text" required />
          </div>
          <div className="form-row">
            <input className="input" placeholder="Correo electrónico" value={email} onChange={e => setEmail(e.target.value)} type="email" required />
          </div>
          <div className="form-row">
            <input className="input" placeholder="Contraseña" value={password} onChange={e => setPassword(e.target.value)} type="password" required />
          </div>

          <div className="form-actions">
            <button className="cta" type="submit">Registrar</button>
            <div className="small-link"><a href="/login">Ya tengo cuenta</a></div>
          </div>

          {error && <div className="auth-error">{error}</div>}
        </form>
      </div>
    </div>
  );
}
