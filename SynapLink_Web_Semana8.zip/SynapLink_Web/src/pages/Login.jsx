import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    try {
      const res = await api.auth.login({ email, password });
      // login returns user and token; with credentials: cookie is set
      if (res && res.user) {
        navigate('/dashboard');
      } else {
        setError('Respuesta inesperada del servidor');
      }
    } catch (err) {
      console.error(err);
      // err.body may contain server JSON with message
      const serverMsg = err && err.body && err.body.message;
      setError(serverMsg || err.message || 'Error de inicio de sesión');
    }
  }

  return (
    <div className="page-container">
      <div className="auth-card">
        <h2>Iniciar sesión</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <input className="input" placeholder="Correo electrónico" value={email} onChange={e => setEmail(e.target.value)} type="email" required />
          </div>
          <div className="form-row">
            <input className="input" placeholder="Contraseña" value={password} onChange={e => setPassword(e.target.value)} type="password" required />
          </div>

          <div className="form-actions">
            <div>
              <button className="cta" type="submit">{/* minimal spinner */}Entrar</button>
            </div>
            <div className="small-link">
              <a href="/register">Crear cuenta</a>
            </div>
          </div>

          {error && <div className="auth-error">{error}</div>}
        </form>
      </div>
    </div>
  );
}
