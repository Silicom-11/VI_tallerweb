export default function LongDescription() {
  const verEnAccion = () => {
    alert('Acción: Ver SynapLink en Acción — video/demo.');
    const el = document.querySelector('#por-que');
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };
  
  const openContact = () => {
    const el = document.querySelector('#contacto');
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };
  
  return (
    <>
      <div className="long-paragraph" role="region" aria-label="Descripción SynapLink">
        <p>
          SynapLink ofrece un software integral para la administración de cabinas e internet cafés que simplifica tus operaciones diarias. 
          Con nuestra plataforma todo-en-uno, podrás controlar las PCs en tiempo real, gestionar reservas, automatizar pagos con QR y 
          optimizar tu negocio de manera sencilla y segura.
        </p>
        <p>
          Con el sistema de reservas inteligentes y el módulo de fidelización de clientes, podrás garantizar una experiencia fluida, 
          rentable y atractiva tanto para ti como para tus usuarios.
        </p>
      </div>
      <div style={{ maxWidth: 980, margin: '6px auto', textAlign: 'right', color: 'var(--muted)', fontWeight: 700, fontStyle: 'italic' }}>
        SynapLink es tu mejor opción!!!
      </div>
      <div className="center-cta">
        <button className="btn-primary" onClick={verEnAccion}>Ver SynapLink en Acción</button>
        <button className="btn-ghost" onClick={openContact}>Solicitar demo</button>
      </div>
      <div className="section">
        <div className="lead-block">
          Si estás abriendo un local de juegos como esports arena, LAN center, cybercafé o PC bang — SynapLink te da herramientas para iniciar rápido y profesionalmente.
        </div>
      </div>
      <div style={{ display: 'flex', justifyContent: 'center', marginTop: 26 }}>
        <button className="btn-primary" onClick={verEnAccion}>Ver SynapLink en Acción</button>
      </div>
    </>
  );
}
