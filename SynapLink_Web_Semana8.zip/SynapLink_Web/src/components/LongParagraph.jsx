export function LongParagraph(){
  return (
    <section className="wrapper" id="story">
      <p className="long-paragraph">
        <b>El soporte tradicional está roto.</b> Flujos fragmentados, tiempos de espera, FAQs que nadie lee y agentes saturados. Mientras tanto tus usuarios esperan inmediatez. SynapLink actúa como un <b>operador cognitivo</b>: interpreta contexto histórico, consulta fuentes autorizadas y ejecuta acciones concretas. No es un chatbot genérico; es una capa neuronal que se acopla a tu stack, reduce costos y aumenta satisfacción.
      </p>
    </section>
  )
}
export default LongParagraph;
