import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

function scrollToId(id) {
  const el = document.querySelector(id);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

export default function Header() {
  const [active, setActive] = useState('#home');
  const navigate = useNavigate();
  const handleNav = useCallback((e, href) => {
    e.preventDefault();
    scrollToId(href);
    setActive(href);
  }, []);

  useEffect(() => {
    const handler = () => {
      const ids = ['#home', '#por-que', '#servicios', '#sobre-nosotros', '#contacto'];
      let current = '#home';
      for (const id of ids) {
        const el = document.querySelector(id);
        if (el) {
          const r = el.getBoundingClientRect();
          if (r.top <= 120 && r.bottom > 160) current = id;
        }
      }
      setActive(current);
    };
    window.addEventListener('scroll', handler, { passive: true });
    handler();
    return () => window.removeEventListener('scroll', handler);
  }, []);

  const navItems = [
    { href: '#home', label: 'Inicio' },
    { href: '#por-que', label: 'Por qué SynapLink?' },
    { href: '#servicios', label: 'Servicios' },
    { href: '#sobre-nosotros', label: 'Sobre Nosotros' },
    { href: '#contacto', label: 'Contáctanos' }
  ];

  return (
    <header role="banner" aria-label="Encabezado SynapLink" className="site-header">
      <div className="brand" aria-hidden>
        <div
          className="logo"
          title="SynapLink"
          style={{
            width: 44,
            height: 44,
            borderRadius: 10,
            background: 'transparent',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            overflow: 'hidden',
            boxShadow: '0 8px 26px rgba(106,90,205,0.16)',
          }}
        >
          <img 
            src="/imagenes/logo.png" 
            alt="SynapLink Logo" 
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'cover',
              borderRadius: '10px'
            }}
          />
        </div>
        <div>
          <div style={{ fontWeight: 800, fontSize: 16 }}>SynapLink</div>
          <div style={{ fontSize: 12, color: 'var(--muted)' }}>Gestión inteligente para cibercafés</div>
        </div>
      </div>
      <nav role="navigation" aria-label="Menú principal" className="main-nav">
        {navItems.map(i => (
          <a
            key={i.href}
            href={i.href}
            onClick={e => handleNav(e, i.href)}
            className={active === i.href ? 'active' : ''}
          >
            {i.label}
          </a>
        ))}
      </nav>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <button className="ghost" onClick={() => navigate('/login')}>Iniciar sesión</button>
        <button className="cta" onClick={() => navigate('/register')}>Pruébalo gratis</button>
      </div>
    </header>
  );
}
