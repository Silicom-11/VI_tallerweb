// Obtener elementos del DOM
const changeColorBtn = document.getElementById('changeColorBtn');
const colorInput = document.getElementById('colorInput');
const dynamicParagraph = document.getElementById('dynamicParagraph');
const resultBox = document.getElementById('resultBox');
const resultText = document.getElementById('resultText');

// Array de colores predeterminados para rotación automática
const defaultColors = [
    '#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', 
    '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E2'
];
let currentColorIndex = 0;

// Función para validar si un color es válido
function isValidColor(color) {
    const s = new Option().style;
    s.color = color;
    return s.color !== '';
}

// Función para cambiar el color del párrafo
function changeParagraphColor() {
    // Obtener el color del input
    const userColor = colorInput.value.trim();
    
    let colorToApply;
    
    if (userColor && isValidColor(userColor)) {
        // Si el usuario escribió un color válido, usarlo
        colorToApply = userColor;
        resultText.textContent = `✓ Color aplicado: ${userColor}`;
        resultText.style.color = '#28a745';
    } else if (userColor) {
        // Si escribió algo pero no es válido
        resultText.textContent = `✗ "${userColor}" no es un color válido. Usando color aleatorio.`;
        resultText.style.color = '#dc3545';
        colorToApply = defaultColors[currentColorIndex];
        currentColorIndex = (currentColorIndex + 1) % defaultColors.length;
    } else {
        // Si no escribió nada, usar un color de la rotación
        colorToApply = defaultColors[currentColorIndex];
        resultText.textContent = `Color aleatorio aplicado: ${colorToApply}`;
        resultText.style.color = '#667eea';
        currentColorIndex = (currentColorIndex + 1) % defaultColors.length;
    }
    
    // Aplicar el color al párrafo y al resultado
    dynamicParagraph.style.backgroundColor = colorToApply;
    dynamicParagraph.style.color = getContrastColor(colorToApply);
    
    resultBox.style.backgroundColor = colorToApply;
    resultBox.style.borderColor = colorToApply;
    
    // Añadir animación
    dynamicParagraph.classList.add('color-changed');
    resultBox.classList.add('color-changed');
    
    setTimeout(() => {
        dynamicParagraph.classList.remove('color-changed');
        resultBox.classList.remove('color-changed');
    }, 500);
}

// Función para obtener color de texto contrastante
function getContrastColor(hexcolor) {
    // Convertir el color a RGB
    const r = parseInt(hexcolor.substr(1, 2), 16);
    const g = parseInt(hexcolor.substr(3, 2), 16);
    const b = parseInt(hexcolor.substr(5, 2), 16);
    
    // Calcular luminancia
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    
    // Retornar blanco o negro según la luminancia
    return luminance > 0.5 ? '#000000' : '#FFFFFF';
}

// Event listener para el botón
changeColorBtn.addEventListener('click', changeParagraphColor);

// Event listener para el input (cambiar al presionar Enter)
colorInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        changeParagraphColor();
    }
});

// Mostrar sugerencias de colores en tiempo real
colorInput.addEventListener('input', (e) => {
    const value = e.target.value.trim();
    if (value) {
        if (isValidColor(value)) {
            colorInput.style.borderColor = '#28a745';
        } else {
            colorInput.style.borderColor = '#dc3545';
        }
    } else {
        colorInput.style.borderColor = '#ddd';
    }
});

// Mensaje inicial
resultText.textContent = 'Escribe un color y haz clic en el botón para ver el resultado';
resultText.style.color = '#999';
