// Obtener elementos del DOM
const walkButton = document.getElementById('walkButton');
const runButton = document.getElementById('runButton');
const stopButton = document.getElementById('stopButton');
const resetButton = document.getElementById('resetButton');
const character = document.getElementById('character');
const shadow = document.getElementById('shadow');
const distanceSpan = document.getElementById('distance');
const statusSpan = document.getElementById('status');
const body = document.body;
const animationArea = document.querySelector('.animation-area');

// Variables de estado
let isWalking = false;
let isRunning = false;
let isPaused = false;
let distance = 0;
let distanceInterval;
let sparkleInterval;
let position = 50; // Posición inicial
let moveInterval; // Para controlar el movimiento
let direction = 1; // 1 = derecha, -1 = izquierda
let speed = 0; // Velocidad actual

// Función para crear efecto de brillos/estrellas
function createSparkle() {
    const sparkle = document.createElement('div');
    sparkle.classList.add('sparkle');
    sparkle.style.left = Math.random() * 100 + '%';
    sparkle.style.top = Math.random() * 100 + '%';
    animationArea.appendChild(sparkle);
    
    setTimeout(() => {
        sparkle.remove();
    }, 1000);
}

// Función para actualizar emojis según el estado
function updateEmojis(moving, mode = 'walking') {
    const head = document.querySelector('.head');
    if (moving) {
        // Alternar entre diferentes expresiones según el modo
        const walkExpressions = ['😊', '😄', '🤗', '😃'];
        const runExpressions = ['😆', '🤩', '😅', '�', '💪'];
        const expressions = mode === 'running' ? runExpressions : walkExpressions;
        let expressionIndex = 0;
        
        const expressionInterval = setInterval(() => {
            if (!isWalking && !isRunning) {
                clearInterval(expressionInterval);
                head.textContent = '😊';
                return;
            }
            head.textContent = expressions[expressionIndex];
            expressionIndex = (expressionIndex + 1) % expressions.length;
        }, mode === 'running' ? 500 : 1000);
    } else {
        head.textContent = '😊';
    }
}

// Función para iniciar la caminata
function startWalking() {
    if (isWalking || isRunning) return;
    
    isWalking = true;
    isRunning = false;
    speed = 2; // Velocidad de caminata
    
    startMovement('walking', '🚶 Caminando...', '¡Caminando! 🎉');
}

// Función para iniciar la carrera
function startRunning() {
    if (isWalking || isRunning) return;
    
    isRunning = true;
    isWalking = false;
    speed = 5; // Velocidad de carrera (más rápida)
    
    startMovement('running', '🏃 Corriendo...', '¡Corriendo a toda velocidad! 🔥');
}

// Función general para iniciar el movimiento
function startMovement(mode, buttonText, statusText) {
    // Agregar clases de animación
    character.classList.add(mode);
    shadow.classList.add(mode);
    body.classList.add('walking');
    
    // Actualizar UI
    walkButton.disabled = true;
    runButton.disabled = true;
    const activeButton = mode === 'walking' ? walkButton : runButton;
    activeButton.textContent = buttonText;
    statusSpan.textContent = statusText;
    statusSpan.style.color = mode === 'running' ? '#ff4500' : '#00ff00';
    
    // Actualizar emojis
    updateEmojis(true, mode);
    
    // Iniciar contador de distancia
    distanceInterval = setInterval(() => {
        distance += (speed * 0.1);
        distanceSpan.textContent = distance.toFixed(1);
    }, 100);
    
    // Crear brillos aleatorios
    sparkleInterval = setInterval(createSparkle, mode === 'running' ? 150 : 300);
    
    // Mover el personaje con JavaScript
    const animationAreaWidth = animationArea.offsetWidth;
    const minPosition = 50;
    const maxPosition = animationAreaWidth - 150;
    
    moveInterval = setInterval(() => {
        if (!isWalking && !isRunning) return;
        
        position += speed * direction;
        character.style.left = position + 'px';
        shadow.style.left = position + 'px';
        
        // Crear huellas
        if (Math.random() > 0.7) {
            createFootprint(position, 50);
        }
        
        // Rebotar en las paredes
        if (position >= maxPosition && direction === 1) {
            direction = -1;
            character.classList.add('flipped');
        } else if (position <= minPosition && direction === -1) {
            direction = 1;
            character.classList.remove('flipped');
        }
    }, 50); // Actualizar cada 50ms para movimiento más suave
}

// Función para detener la caminata
function stopWalking(message = 'Detenido ⏸️') {
    if (!isWalking && !isRunning) return;
    
    isWalking = false;
    isRunning = false;
    
    // Remover clases de animación
    character.classList.remove('walking', 'running');
    shadow.classList.remove('walking', 'running');
    body.classList.remove('walking');
    
    // Actualizar UI
    walkButton.disabled = false;
    runButton.disabled = false;
    walkButton.textContent = '🚶 ¡Haz que camine!';
    runButton.textContent = '🏃 ¡Haz que corra!';
    statusSpan.textContent = message;
    statusSpan.style.color = '#ffff00';
    
    // Detener intervalos
    clearInterval(distanceInterval);
    clearInterval(sparkleInterval);
    clearInterval(moveInterval);
    
    // Restaurar emojis
    updateEmojis(false);
}

// Función para reiniciar
function resetAnimation() {
    stopWalking('Reiniciado 🔄');
    
    // Remover clases
    character.classList.remove('walking', 'running', 'flipped');
    shadow.classList.remove('walking', 'running');
    
    // Reiniciar posición y dirección
    position = 50;
    direction = 1;
    character.style.left = '50px';
    shadow.style.left = '50px';
    
    // Reiniciar distancia
    distance = 0;
    distanceSpan.textContent = '0';
    statusSpan.textContent = 'Esperando...';
    statusSpan.style.color = '#ffffff';
    
    // Reiniciar fondo
    body.classList.remove('walking');
}

// Event Listeners
walkButton.addEventListener('click', startWalking);

runButton.addEventListener('click', startRunning);

stopButton.addEventListener('click', () => {
    stopWalking('Pausado ⏸️');
});

resetButton.addEventListener('click', resetAnimation);

// Agregar efectos de sonido simulados (opcional)
walkButton.addEventListener('mouseenter', () => {
    if (!walkButton.disabled) {
        walkButton.style.transform = 'translateY(-5px) scale(1.05) rotate(2deg)';
    }
});

walkButton.addEventListener('mouseleave', () => {
    walkButton.style.transform = '';
});

runButton.addEventListener('mouseenter', () => {
    if (!runButton.disabled) {
        runButton.style.transform = 'translateY(-5px) scale(1.05) rotate(-2deg)';
    }
});

runButton.addEventListener('mouseleave', () => {
    runButton.style.transform = '';
});

// Añadir partículas en el camino
let particleTimeout;
function createFootprint(x, y) {
    const footprint = document.createElement('div');
    footprint.style.position = 'absolute';
    footprint.style.left = x + 'px';
    footprint.style.bottom = y + 'px';
    footprint.style.fontSize = '20px';
    footprint.textContent = '👣';
    footprint.style.opacity = '0.5';
    footprint.style.transition = 'opacity 2s';
    animationArea.appendChild(footprint);
    
    setTimeout(() => {
        footprint.style.opacity = '0';
        setTimeout(() => footprint.remove(), 2000);
    }, 100);
}

// Crear huellas mientras camina
character.addEventListener('animationstart', () => {
    if (isWalking) {
        const createFootprintInterval = setInterval(() => {
            if (!isWalking) {
                clearInterval(createFootprintInterval);
                return;
            }
            const rect = character.getBoundingClientRect();
            const containerRect = animationArea.getBoundingClientRect();
            const x = rect.left - containerRect.left;
            const y = 50;
            createFootprint(x, y);
        }, 800);
    }
});

// Mensaje de bienvenida
console.log('🎨 ¡Práctica 2 cargada! Haz clic en el botón para ver la magia ✨');
