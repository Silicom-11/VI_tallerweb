// Elementos del DOM
const mainFace = document.getElementById('mainFace');
const eyes = document.getElementById('eyes');
const leftEye = document.getElementById('leftEye');
const rightEye = document.getElementById('rightEye');
const mouth = document.getElementById('mouth');
const extras = document.getElementById('extras');
const emotionLabel = document.getElementById('emotionLabel');
const emotionDescription = document.getElementById('emotionDescription');
const emotionButtons = document.querySelectorAll('.emotion-btn');
const randomBtn = document.getElementById('randomBtn');
const animationBtn = document.getElementById('animationBtn');
const rainbowBtn = document.getElementById('rainbowBtn');
const currentEmotionSpan = document.getElementById('currentEmotion');
const changeCountSpan = document.getElementById('changeCount');
const modeStatusSpan = document.getElementById('modeStatus');
const particlesContainer = document.getElementById('particles');
const subtitle = document.getElementById('subtitle');
const mainTitle = document.getElementById('mainTitle');

// Variables de estado
let changeCount = 0;
let autoMode = false;
let autoInterval = null;
let rainbowMode = false;

// Configuración de emociones
const emotions = {
    feliz: {
        name: '😊 Feliz',
        description: '¡La felicidad es contagiosa!',
        faceColor: 'linear-gradient(135deg, #ffd700 0%, #ffed4e 100%)',
        eyeStyle: 'happy',
        mouthStyle: 'happy',
        extras: null
    },
    triste: {
        name: '😢 Triste',
        description: 'A veces está bien sentirse así...',
        faceColor: 'linear-gradient(135deg, #6dd5ed 0%, #2193b0 100%)',
        eyeStyle: 'sad',
        mouthStyle: 'sad',
        extras: 'tears'
    },
    enojado: {
        name: '😠 Enojado',
        description: '¡Necesito calmarme!',
        faceColor: 'linear-gradient(135deg, #ff6b6b 0%, #ee5a6f 100%)',
        eyeStyle: 'angry',
        mouthStyle: 'angry',
        extras: 'steam'
    },
    sorprendido: {
        name: '😲 Sorprendido',
        description: '¡No puedo creerlo!',
        faceColor: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
        eyeStyle: 'surprised',
        mouthStyle: 'surprised',
        extras: null
    },
    enamorado: {
        name: '😍 Enamorado',
        description: 'El amor está en el aire ❤️',
        faceColor: 'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)',
        eyeStyle: 'love',
        mouthStyle: 'happy',
        extras: 'hearts'
    },
    risa: {
        name: '😂 Risa',
        description: '¡Jajajaja no puedo parar!',
        faceColor: 'linear-gradient(135deg, #ffeaa7 0%, #fdcb6e 100%)',
        eyeStyle: 'laughing',
        mouthStyle: 'laughing',
        extras: 'tears-joy'
    },
    miedo: {
        name: '😨 Miedo',
        description: '¿Qué fue ese ruido?',
        faceColor: 'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',
        eyeStyle: 'scared',
        mouthStyle: 'scared',
        extras: 'sweat'
    },
    disgustado: {
        name: '🤢 Disgustado',
        description: 'Eso no se ve bien...',
        faceColor: 'linear-gradient(135deg, #c3ec52 0%, #0ba360 100%)',
        eyeStyle: 'disgusted',
        mouthStyle: 'disgusted',
        extras: null
    },
    pensativo: {
        name: '🤔 Pensativo',
        description: 'Hmm... déjame pensar...',
        faceColor: 'linear-gradient(135deg, #fbc2eb 0%, #a6c1ee 100%)',
        eyeStyle: 'thinking',
        mouthStyle: 'thinking',
        extras: 'question'
    },
    cansado: {
        name: '😴 Cansado',
        description: 'Necesito dormir...',
        faceColor: 'linear-gradient(135deg, #e0c3fc 0%, #8ec5fc 100%)',
        eyeStyle: 'sleepy',
        mouthStyle: 'neutral',
        extras: 'zzz'
    },
    guiño: {
        name: '😉 Guiño',
        description: '¡Ya sabes de qué hablo!',
        faceColor: 'linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)',
        eyeStyle: 'wink',
        mouthStyle: 'smirk',
        extras: null
    },
    loco: {
        name: '🤪 Loco',
        description: '¡Fiesta todo el día!',
        faceColor: 'linear-gradient(135deg, #ff9a9e 0%, #fad0c4 100%)',
        eyeStyle: 'crazy',
        mouthStyle: 'crazy',
        extras: 'confetti'
    },
    angel: {
        name: '😇 Ángel',
        description: 'Soy un ser de luz ✨',
        faceColor: 'linear-gradient(135deg, #ffffff 0%, #e0e0e0 100%)',
        eyeStyle: 'happy',
        mouthStyle: 'happy',
        extras: 'halo'
    },
    diablo: {
        name: '😈 Diablo',
        description: 'Un poco de maldad no hace daño...',
        faceColor: 'linear-gradient(135deg, #cb2d3e 0%, #ef473a 100%)',
        eyeStyle: 'evil',
        mouthStyle: 'evil',
        extras: 'horns'
    },
    robot: {
        name: '🤖 Robot',
        description: 'Beep boop... procesando...',
        faceColor: 'linear-gradient(135deg, #d3d3d3 0%, #a0a0a0 100%)',
        eyeStyle: 'robot',
        mouthStyle: 'robot',
        extras: 'antenna'
    },
    alien: {
        name: '👽 Alien',
        description: '¡Vengo en son de paz!',
        faceColor: 'linear-gradient(135deg, #7bed9f 0%, #2ed573 100%)',
        eyeStyle: 'alien',
        mouthStyle: 'alien',
        extras: null
    }
};

// Inicializar partículas
function createParticles() {
    for (let i = 0; i < 30; i++) {
        const particle = document.createElement('div');
        particle.classList.add('particle');
        particle.style.left = Math.random() * 100 + '%';
        particle.style.animationDelay = Math.random() * 6 + 's';
        particle.style.animationDuration = (Math.random() * 4 + 4) + 's';
        particlesContainer.appendChild(particle);
    }
}

// Cambiar emoción
function changeEmotion(emotionKey) {
    const emotion = emotions[emotionKey];
    if (!emotion) return;
    
    changeCount++;
    changeCountSpan.textContent = changeCount;
    currentEmotionSpan.textContent = emotion.name;
    
    // Actualizar UI
    emotionLabel.textContent = emotion.name;
    emotionDescription.textContent = emotion.description;
    mainFace.style.background = emotion.faceColor;
    
    // Aplicar estilos de ojos
    applyEyeStyle(emotion.eyeStyle);
    
    // Aplicar estilos de boca
    applyMouthStyle(emotion.mouthStyle);
    
    // Aplicar extras
    applyExtras(emotion.extras);
    
    // Animación de entrada
    mainFace.style.animation = 'none';
    setTimeout(() => {
        mainFace.style.animation = 'faceBounce 3s ease-in-out infinite';
    }, 10);
    
    // Efecto de rebote
    mainFace.style.transform = 'scale(1.2) rotate(5deg)';
    setTimeout(() => {
        mainFace.style.transform = 'scale(1) rotate(0deg)';
    }, 300);
    
    // Actualizar botón activo
    emotionButtons.forEach(btn => btn.classList.remove('active'));
    const activeBtn = document.querySelector(`[data-emotion="${emotionKey}"]`);
    if (activeBtn) activeBtn.classList.add('active');
    
    // Crear efecto de explosión
    createExplosion();
}

// Estilos de ojos
function applyEyeStyle(style) {
    // Reset
    leftEye.style.width = '50px';
    leftEye.style.height = '50px';
    rightEye.style.width = '50px';
    rightEye.style.height = '50px';
    leftEye.style.borderRadius = '50%';
    rightEye.style.borderRadius = '50%';
    leftEye.innerHTML = '<div class="pupil"></div>';
    rightEye.innerHTML = '<div class="pupil"></div>';
    
    switch(style) {
        case 'happy':
            leftEye.style.height = '30px';
            rightEye.style.height = '30px';
            break;
        case 'sad':
            leftEye.style.transform = 'rotate(-10deg)';
            rightEye.style.transform = 'rotate(10deg)';
            break;
        case 'angry':
            leftEye.style.transform = 'rotate(20deg) translateY(-5px)';
            rightEye.style.transform = 'rotate(-20deg) translateY(-5px)';
            break;
        case 'surprised':
            leftEye.style.width = '65px';
            leftEye.style.height = '65px';
            rightEye.style.width = '65px';
            rightEye.style.height = '65px';
            break;
        case 'love':
            leftEye.innerHTML = '<div style="font-size:40px; color:#ff0080;">❤️</div>';
            rightEye.innerHTML = '<div style="font-size:40px; color:#ff0080;">❤️</div>';
            break;
        case 'laughing':
            leftEye.innerHTML = '<div style="width:40px; height:8px; background:#333; border-radius:10px; margin-top:20px;"></div>';
            rightEye.innerHTML = '<div style="width:40px; height:8px; background:#333; border-radius:10px; margin-top:20px;"></div>';
            break;
        case 'scared':
            leftEye.style.width = '60px';
            leftEye.style.height = '70px';
            rightEye.style.width = '60px';
            rightEye.style.height = '70px';
            leftEye.style.borderRadius = '50% 50% 40% 40%';
            rightEye.style.borderRadius = '50% 50% 40% 40%';
            break;
        case 'disgusted':
            leftEye.style.width = '40px';
            leftEye.style.height = '35px';
            rightEye.style.width = '40px';
            rightEye.style.height = '35px';
            leftEye.style.transform = 'rotate(-15deg)';
            rightEye.style.transform = 'rotate(15deg)';
            break;
        case 'thinking':
            leftEye.style.height = '35px';
            rightEye.style.height = '35px';
            rightEye.style.transform = 'translateY(-5px)';
            break;
        case 'sleepy':
            leftEye.style.height = '15px';
            rightEye.style.height = '15px';
            break;
        case 'wink':
            leftEye.style.height = '30px';
            rightEye.style.height = '8px';
            rightEye.innerHTML = '<div style="width:40px; height:5px; background:#333; border-radius:10px; margin-top:20px;"></div>';
            break;
        case 'crazy':
            leftEye.style.transform = 'rotate(15deg) scale(1.3)';
            rightEye.style.transform = 'rotate(-25deg) scale(0.8)';
            break;
        case 'evil':
            leftEye.innerHTML = '<div class="pupil" style="background:#ff0000; width:30px; height:30px;"></div>';
            rightEye.innerHTML = '<div class="pupil" style="background:#ff0000; width:30px; height:30px;"></div>';
            leftEye.style.transform = 'rotate(15deg)';
            rightEye.style.transform = 'rotate(-15deg)';
            break;
        case 'robot':
            leftEye.style.borderRadius = '10px';
            rightEye.style.borderRadius = '10px';
            leftEye.innerHTML = '<div style="width:20px; height:20px; background:#00ff00; border-radius:5px; margin:15px auto;"></div>';
            rightEye.innerHTML = '<div style="width:20px; height:20px; background:#00ff00; border-radius:5px; margin:15px auto;"></div>';
            break;
        case 'alien':
            leftEye.style.width = '70px';
            leftEye.style.height = '70px';
            rightEye.style.width = '70px';
            rightEye.style.height = '70px';
            leftEye.style.background = '#000';
            rightEye.style.background = '#000';
            break;
    }
}

// Estilos de boca
function applyMouthStyle(style) {
    mouth.style.width = '100px';
    mouth.style.height = '50px';
    mouth.style.border = '5px solid #333';
    mouth.style.borderTop = 'none';
    mouth.style.borderRadius = '0 0 100px 100px';
    mouth.style.background = 'none';
    mouth.style.transform = 'translateX(-50%)';
    
    switch(style) {
        case 'happy':
            mouth.style.borderRadius = '0 0 100px 100px';
            break;
        case 'sad':
            mouth.style.borderTop = '5px solid #333';
            mouth.style.borderBottom = 'none';
            mouth.style.borderRadius = '100px 100px 0 0';
            break;
        case 'angry':
            mouth.style.width = '80px';
            mouth.style.height = '30px';
            mouth.style.borderRadius = '0 0 50px 50px';
            break;
        case 'surprised':
            mouth.style.width = '60px';
            mouth.style.height = '60px';
            mouth.style.borderRadius = '50%';
            mouth.style.border = '5px solid #333';
            mouth.style.background = '#000';
            break;
        case 'laughing':
            mouth.style.width = '120px';
            mouth.style.height = '70px';
            mouth.style.borderRadius = '0 0 120px 120px';
            mouth.style.background = '#ff69b4';
            break;
        case 'scared':
            mouth.style.width = '70px';
            mouth.style.height = '80px';
            mouth.style.borderRadius = '50%';
            mouth.style.border = '5px solid #333';
            break;
        case 'disgusted':
            mouth.style.width = '60px';
            mouth.style.height = '30px';
            mouth.style.transform = 'translateX(-50%) rotate(15deg)';
            break;
        case 'thinking':
            mouth.style.width = '70px';
            mouth.style.height = '20px';
            mouth.style.borderRadius = '0 0 50px 50px';
            mouth.style.transform = 'translateX(-50%) translateX(10px)';
            break;
        case 'neutral':
            mouth.style.border = 'none';
            mouth.style.borderTop = '5px solid #333';
            mouth.style.width = '80px';
            mouth.style.height = '0';
            mouth.style.borderRadius = '0';
            break;
        case 'smirk':
            mouth.style.width = '80px';
            mouth.style.height = '40px';
            mouth.style.transform = 'translateX(-50%) rotate(-10deg)';
            break;
        case 'crazy':
            mouth.style.width = '90px';
            mouth.style.height = '50px';
            mouth.style.transform = 'translateX(-50%) rotate(20deg)';
            break;
        case 'evil':
            mouth.style.borderRadius = '0 0 100px 100px';
            mouth.style.width = '110px';
            mouth.style.background = '#000';
            break;
        case 'robot':
            mouth.style.borderRadius = '10px';
            mouth.style.width = '80px';
            mouth.style.height = '20px';
            mouth.style.border = '5px solid #333';
            break;
        case 'alien':
            mouth.style.width = '40px';
            mouth.style.height = '20px';
            mouth.style.borderRadius = '50%';
            break;
    }
}

// Aplicar extras
function applyExtras(type) {
    extras.innerHTML = '';
    
    if (!type) return;
    
    switch(type) {
        case 'tears':
            extras.innerHTML = `
                <div style="position:absolute; bottom:25%; left:15%; font-size:40px; animation: fall 2s ease-in infinite;">💧</div>
                <div style="position:absolute; bottom:25%; right:15%; font-size:40px; animation: fall 2s ease-in infinite 0.5s;">💧</div>
            `;
            break;
        case 'steam':
            extras.innerHTML = `
                <div style="position:absolute; top:10%; left:10%; font-size:30px; animation: steam 2s ease-in-out infinite;">💨</div>
                <div style="position:absolute; top:10%; right:10%; font-size:30px; animation: steam 2s ease-in-out infinite 0.5s;">💨</div>
            `;
            break;
        case 'hearts':
            extras.innerHTML = `
                <div style="position:absolute; top:0%; left:50%; font-size:30px; animation: float 2s ease-in-out infinite; transform:translateX(-50%);">❤️</div>
                <div style="position:absolute; top:-10%; left:20%; font-size:25px; animation: float 2s ease-in-out infinite 0.3s;">💕</div>
                <div style="position:absolute; top:-10%; right:20%; font-size:25px; animation: float 2s ease-in-out infinite 0.6s;">💖</div>
            `;
            break;
        case 'tears-joy':
            extras.innerHTML = `
                <div style="position:absolute; bottom:30%; left:10%; font-size:35px; animation: fall 1.5s ease-in infinite;">😂</div>
                <div style="position:absolute; bottom:30%; right:10%; font-size:35px; animation: fall 1.5s ease-in infinite 0.3s;">😂</div>
            `;
            break;
        case 'sweat':
            extras.innerHTML = `
                <div style="position:absolute; top:20%; right:20%; font-size:35px; animation: fall 2s ease-in infinite;">💦</div>
            `;
            break;
        case 'question':
            extras.innerHTML = `
                <div style="position:absolute; top:-15%; right:10%; font-size:50px; animation: float 2s ease-in-out infinite;">❓</div>
            `;
            break;
        case 'zzz':
            extras.innerHTML = `
                <div style="position:absolute; top:-10%; right:15%; font-size:40px; animation: float 2s ease-in-out infinite;">💤</div>
            `;
            break;
        case 'confetti':
            extras.innerHTML = `
                <div style="position:absolute; top:-20%; left:20%; font-size:30px; animation: confetti 1s ease-in-out infinite;">🎉</div>
                <div style="position:absolute; top:-20%; right:20%; font-size:30px; animation: confetti 1s ease-in-out infinite 0.3s;">🎊</div>
            `;
            break;
        case 'halo':
            extras.innerHTML = `
                <div style="position:absolute; top:-20%; left:50%; transform:translateX(-50%); font-size:60px; animation: float 2s ease-in-out infinite;">😇</div>
            `;
            break;
        case 'horns':
            extras.innerHTML = `
                <div style="position:absolute; top:-10%; left:10%; font-size:40px; transform:rotate(-30deg);">🔥</div>
                <div style="position:absolute; top:-10%; right:10%; font-size:40px; transform:rotate(30deg);">🔥</div>
            `;
            break;
        case 'antenna':
            extras.innerHTML = `
                <div style="position:absolute; top:-15%; left:50%; transform:translateX(-50%); width:4px; height:40px; background:#666;"></div>
                <div style="position:absolute; top:-20%; left:50%; transform:translateX(-50%); width:20px; height:20px; background:#ff0000; border-radius:50%; animation: blink 1s ease infinite;"></div>
            `;
            break;
    }
    
    // Agregar estilos de animación inline
    if (!document.getElementById('emotion-animations')) {
        const style = document.createElement('style');
        style.id = 'emotion-animations';
        style.textContent = `
            @keyframes fall {
                0% { transform: translateY(0); opacity: 1; }
                100% { transform: translateY(100px); opacity: 0; }
            }
            @keyframes steam {
                0% { transform: translateY(0) scale(1); opacity: 1; }
                100% { transform: translateY(-50px) scale(1.5); opacity: 0; }
            }
            @keyframes confetti {
                0% { transform: translateY(0) rotate(0deg); opacity: 1; }
                100% { transform: translateY(100px) rotate(360deg); opacity: 0; }
            }
            @keyframes blink {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.3; }
            }
        `;
        document.head.appendChild(style);
    }
}

// Crear explosión de partículas
function createExplosion() {
    const colors = ['#ff0080', '#ff8c00', '#40e0d0', '#4169e1', '#ffd700'];
    for (let i = 0; i < 20; i++) {
        const particle = document.createElement('div');
        particle.style.position = 'absolute';
        particle.style.width = '10px';
        particle.style.height = '10px';
        particle.style.background = colors[Math.floor(Math.random() * colors.length)];
        particle.style.borderRadius = '50%';
        particle.style.left = '50%';
        particle.style.top = '50%';
        particle.style.pointerEvents = 'none';
        
        const angle = (Math.PI * 2 * i) / 20;
        const velocity = 100 + Math.random() * 100;
        const tx = Math.cos(angle) * velocity;
        const ty = Math.sin(angle) * velocity;
        
        mainFace.appendChild(particle);
        
        particle.animate([
            { transform: 'translate(-50%, -50%) translate(0, 0) scale(1)', opacity: 1 },
            { transform: `translate(-50%, -50%) translate(${tx}px, ${ty}px) scale(0)`, opacity: 0 }
        ], {
            duration: 1000,
            easing: 'ease-out'
        }).onfinish = () => particle.remove();
    }
}

// Event listeners para botones de emociones
emotionButtons.forEach(btn => {
    btn.addEventListener('click', () => {
        const emotion = btn.getAttribute('data-emotion');
        changeEmotion(emotion);
    });
});

// Botón aleatorio
randomBtn.addEventListener('click', () => {
    const emotionKeys = Object.keys(emotions);
    const randomKey = emotionKeys[Math.floor(Math.random() * emotionKeys.length)];
    changeEmotion(randomKey);
});

// Modo automático
animationBtn.addEventListener('click', () => {
    autoMode = !autoMode;
    
    if (autoMode) {
        animationBtn.classList.add('active');
        animationBtn.textContent = '⏸️ Detener Auto';
        modeStatusSpan.textContent = 'Automático';
        
        autoInterval = setInterval(() => {
            const emotionKeys = Object.keys(emotions);
            const randomKey = emotionKeys[Math.floor(Math.random() * emotionKeys.length)];
            changeEmotion(randomKey);
        }, 3000);
    } else {
        animationBtn.classList.remove('active');
        animationBtn.textContent = '✨ Modo Automático';
        modeStatusSpan.textContent = 'Manual';
        clearInterval(autoInterval);
    }
});

// Modo arcoíris
rainbowBtn.addEventListener('click', () => {
    rainbowMode = !rainbowMode;
    document.body.classList.toggle('rainbow-mode', rainbowMode);
    
    if (rainbowMode) {
        rainbowBtn.classList.add('active');
    } else {
        rainbowBtn.classList.remove('active');
    }
});

// Seguimiento del mouse en los ojos
document.addEventListener('mousemove', (e) => {
    const pupils = document.querySelectorAll('.pupil');
    pupils.forEach(pupil => {
        const eye = pupil.parentElement;
        const rect = eye.getBoundingClientRect();
        const eyeX = rect.left + rect.width / 2;
        const eyeY = rect.top + rect.height / 2;
        
        const angle = Math.atan2(e.clientY - eyeY, e.clientX - eyeX);
        const distance = Math.min(10, Math.sqrt(Math.pow(e.clientX - eyeX, 2) + Math.pow(e.clientY - eyeY, 2)) / 10);
        
        const pupilX = Math.cos(angle) * distance;
        const pupilY = Math.sin(angle) * distance;
        
        pupil.style.transform = `translate(calc(-50% + ${pupilX}px), calc(-50% + ${pupilY}px))`;
    });
});

// Inicialización
createParticles();
changeEmotion('feliz');

// Mensaje de bienvenida con efecto de escritura
let titleText = '🎭 Selector de Emociones 🎨';
let subtitleText = '¡Explora las emociones y observa la magia!';
let titleIndex = 0;
let subtitleIndex = 0;

mainTitle.textContent = '';
subtitle.textContent = '';

function typeTitle() {
    if (titleIndex < titleText.length) {
        mainTitle.textContent += titleText.charAt(titleIndex);
        titleIndex++;
        setTimeout(typeTitle, 100);
    } else {
        setTimeout(typeSubtitle, 500);
    }
}

function typeSubtitle() {
    if (subtitleIndex < subtitleText.length) {
        subtitle.textContent += subtitleText.charAt(subtitleIndex);
        subtitleIndex++;
        setTimeout(typeSubtitle, 50);
    }
}

setTimeout(typeTitle, 500);

console.log('🎭 ¡Práctica 3 cargada! Explora todas las emociones 🎨');
